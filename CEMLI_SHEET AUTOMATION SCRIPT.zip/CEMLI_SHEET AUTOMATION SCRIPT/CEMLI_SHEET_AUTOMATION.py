import os
import sys
import time
import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options  
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import StaleElementReferenceException
from selenium.common.exceptions import NoSuchElementException

#chrome_options = Options()  
#chrome_options.add_argument("--headless")  
#, chrome_options=chrome_options

driver = webdriver.Chrome(os.path.join(os.getcwd()+"/chromedriver.exe"))
driver.maximize_window()
dirName = 'tempDir'
CREDENTIALS_LIST = ["GEEMAIL_ID","SSOID","SSOID_PASSWORD"]
filename = datetime.datetime.now()
if not os.path.exists('tempDir'):
    os.makedirs(dirName)
filepath = os.path.join(os.getcwd()+"/tempDir", filename.strftime("%d_%B_%Y %H_%M_%S")+"logfile.txt")
with open(filepath, "a") as fp:
    pass
    
    print("Entered Credential Details for Login are as Below:- \n")
    print("Login Email ID :- " + CREDENTIALS_LIST[0] + "\n")
    print("SSOID :- "  + CREDENTIALS_LIST[1] +"\n")
    print("If There are Many JIRA's please enter in Comma Seperated Format eg:- ABC-1,DEF-2...")
    print("\n")
    fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "CEMLI SHEET CREATION STARTED \n")
    CEMLI_NAME_ENTER = input("Enter CEMLI / JIRA Name's :- ")
    CEMLI_NAME_LIST = list(CEMLI_NAME_ENTER.split(","))
    
    for CEMLI_NAME in CEMLI_NAME_LIST:
        
        print("***************** CEMLI Creation Started for " + CEMLI_NAME + "***************** ")
        fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "CEMLI SHEET CREATION STARTED for CEMLI NAME:-  " +CEMLI_NAME +"\n")
        driver.get('https://geappliances.sharepoint.com/sites/erpdevops/SitePages/SOA.aspx')
        try:
            inputElement = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, "i0116")))
            inputElement.send_keys(CREDENTIALS_LIST[0])
            fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Email ID Entered \n")
            submit_button = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, "idSIButton9")))
            submit_button.click()
            fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Clicked on SUBMIT Button \n")
            SSOID = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.NAME, "username")))
            SSOID.send_keys(CREDENTIALS_LIST[1])
            fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Entered User Name / SSOID \n")
            SSOPWD = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.NAME, "password")))
            SSOPWD.send_keys(CREDENTIALS_LIST[2])
            fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Entered Password for the above entered SSOID \n")
            SSOSUBMIT = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.NAME, "submit")))
            SSOSUBMIT.click()
            fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click of Submit Button \n")
            Remember = WebDriverWait(driver, 120).until(EC.visibility_of_element_located((By.ID, "idSIButton9")))
            Remember.click()
            fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click of remember Button \n")
            AddNewPage = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, "idHomePageNewWikiPage")))
            AddNewPage.click()
            fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on Add New page \n")
            EnterCemliName = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, "ctl00_PlaceHolderMain_nameInput")))
            EnterCemliName.send_keys(CEMLI_NAME)
            fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Entered CEMLI Name \n")
            CemliCreate = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, "ctl00_PlaceHolderMain_createButton")))
            CemliCreate.click()
            fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on CREATE CEMLI Page \n")
            time.sleep(3)
            if driver.find_elements_by_xpath("//span[contains(@class,'ms-error') and .//text()='The specified name is already in use.']"):
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Entered Cemli Page Already Exists \n")
                sys.exit("Process terminated Because CEMLI Page Already Exists")
            else:
                EditSourceClick = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, "Ribbon.EditingTools.CPEditTab.Markup.Html.Menu.Html.EditSource-Large")))
                EditSourceClick.click()
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on Edit Source \n")
                HTMLCode = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, "PropertyEditor")))
                HTMLCode.clear()
                x = '<table width="1313" cellspacing="0" height="954" class="ms-rteTable-0"> <tbody> <tr class="ms-rteTableEvenRow-0"> <td class="ms-rteTableEvenCol-0" style="width: 50%;"> <table width="100%" cellspacing="0" class="ms-rteTable-default"> <tbody> <tr class="ms-rteTableEvenRow-default"> <td class="ms-rteTableEvenCol-default" colspan="2" style="width: 50%;"> <strong class="ms-rteFontSize-3">INFORMATION</strong></td> </tr> <tr class="ms-rteTableOddRow-default"> <td valign="top" class="ms-rteTableEvenCol-default" style="width: 13%;"> <strong>JIRA Ticket</strong><br/></td> <td valign="top" class="ms-rteTableOddCol-default"> <br/> </td> </tr> <tr class="ms-rteTableEvenRow-default"> <td valign="top" class="ms-rteTableEvenCol-default"> <strong>Name</strong><br/></td> <td valign="top" class="ms-rteTableOddCol-default"> <br/> </td> </tr> <tr class="ms-rteTableEvenRow-default"> <td valign="top" class="ms-rteTableEvenCol-default"> <strong>Description</strong><br/></td> <td valign="top" class="ms-rteTableOddCol-default"> <br/> </td> </tr> <tr class="ms-rteTableOddRow-default"> <td valign="top" class="ms-rteTableEvenCol-default"> <strong>Source</strong><br/></td> <td valign="top" class="ms-rteTableOddCol-default"> Source CI: <br/>Database Table: <br/>Directory: <br/>File: <br/></td> </tr> <tr class="ms-rteTableEvenRow-default"> <td valign="top" class="ms-rteTableEvenCol-default"> <strong>Integration</strong><br/></td> <td valign="top" class="ms-rteTableOddCol-default">Integration CI: <br/>Objects: <br/></td> </tr> <tr class="ms-rteTableOddRow-default"> <td class="ms-rteTableEvenCol-default"> <strong>Target</strong></td> <td class="ms-rteTableOddCol-default">Target CI: <br/>API: <br/>Database Table: <br/>Directory: <br/>File: <br/></td> </tr> <tr class="ms-rteTableEvenRow-default"> <td class="ms-rteTableEvenCol-default"> <strong>Dependencies</strong></td> <td class="ms-rteTableOddCol-default">?</td> </tr> <tr class="ms-rteTableOddRow-default"> <td class="ms-rteTableEvenCol-default"> <strong>External</strong></td> <td class="ms-rteTableOddCol-default">?</td> </tr> <tr class="ms-rteTableEvenRow-default"> <td class="ms-rteTableEvenCol-default"> <strong>Contacts</strong></td> <td class="ms-rteTableOddCol-default">Source: <br/>Integration: <br/>Target: <br/></td> </tr> <tr class="ms-rteTableOddRow-default"> <td class="ms-rteTableEvenCol-default"> <strong>Reprocessing</strong></td> <td class="ms-rteTableOddCol-default">?</td> </tr> <tr class="ms-rteTableEvenRow-default"> <td class="ms-rteTableEvenCol-default"> <strong>Regression Testing</strong><br/></td> <td class="ms-rteTableOddCol-default">?</td> </tr> <tr class="ms-rteTableOddRow-default"> <td class="ms-rteTableEvenCol-default"> <strong>Support Transition Status</strong><br/></td> <td class="ms-rteTableOddCol-default">MD2060: <br/>Code Walk Through: <br/>CEMLI Page: <br/>Final Sign Off: <br/> </td> </tr> <tr class="ms-rteTableEvenRow-default"> <td class="ms-rteTableEvenCol-default"> <strong>Sample Payload</strong><br/></td> <td class="ms-rteTableOddCol-default">?</td> </tr> <tr class="ms-rteTableOddRow-default"> <td class="ms-rteTableEvenCol-default"> <strong>non-PROD Details</strong><br/></td> <td class="ms-rteTableOddCol-default">dev: <br/>tst: <br/>qa/stg: <br/></td> </tr> </tbody> </table> </td> <td class="ms-rteTableOddCol-0" style="width: 50%;"> <table width="100%" cellspacing="0" class="ms-rteTable-default"> <tbody> <tr class="ms-rteTableEvenRow-default"> <td class="ms-rteTableEvenCol-default" colspan="2" style="width: 50%;"> <strong><span><span><strong class="ms-rteFontSize-3">FAILURE MODES<br/></strong></span></span></strong></td> </tr> <tr class="ms-rteTableOddRow-default"> <td class="ms-rteTableEvenCol-default" style="width: 5%;">#1</td> <td class="ms-rteTableOddCol-default">Object: <br/>CI: <br/>Message: <br/>Action: <br/></td> </tr> <tr class="ms-rteTableEvenRow-default"> <td class="ms-rteTableEvenCol-default">#2</td> <td class="ms-rteTableOddCol-default">Object: <br/>CI: <br/>Message: <br/>Action: <br/></td> </tr> <tr class="ms-rteTableOddRow-default"> <td class="ms-rteTableEvenCol-default">#3</td> <td class="ms-rteTableOddCol-default">Object: <br/>CI: <br/>Message: <br/>Action: <br/></td> </tr> <tr class="ms-rteTableEvenRow-default"> <td class="ms-rteTableEvenCol-default">#4</td> <td class="ms-rteTableOddCol-default">Object: <br/>CI: <br/>Message: <br/>Action: <br/></td> </tr> <tr class="ms-rteTableOddRow-default"> <td class="ms-rteTableEvenCol-default">#5</td> <td class="ms-rteTableOddCol-default">Object: <br/>CI: <br/>Message: <br/>Action: <br/></td> </tr> <tr class="ms-rteTableEvenRow-default"> <td class="ms-rteTableEvenCol-default">#6</td> <td class="ms-rteTableOddCol-default">Object: <br/>CI: <br/>Message: <br/>Action: <br/></td> </tr> <tr class="ms-rteTableOddRow-default"> <td class="ms-rteTableEvenCol-default">#7</td> <td class="ms-rteTableOddCol-default">Object: <br/>CI: <br/>Message: <br/>Action: <br/></td> </tr> <tr class="ms-rteTableEvenRow-default"> <td class="ms-rteTableEvenCol-default">#8</td> <td class="ms-rteTableOddCol-default">Object: <br/>CI: <br/>Message: <br/>Action: <br/></td> </tr> <tr class="ms-rteTableOddRow-default"> <td class="ms-rteTableEvenCol-default">#9</td> <td class="ms-rteTableOddCol-default">Object: <br/>CI: <br/>Message: <br/>Action: <br/></td> </tr> <tr class="ms-rteTableFooterRow-default"> <td class="ms-rteTableFooterEvenCol-default" rowspan="1">#10</td> <td class="ms-rteTableOddCol-default">Object: <br/>CI: <br/>Message: <br/>Action: <br/></td> </tr> </tbody> </table> </td> </tr> </tbody></table><p> <br/></p>'
                HTMLCode.send_keys(x)
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Entered HTML Content for CEMLI Page \n")
                time.sleep(3)
                HTMLCodeSubmit = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, "sourcedialog_okbutton")))
                HTMLCodeSubmit.click()
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on OK Button After entering HTML Content \n")
                Checkin = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, "Ribbon.EditingTools.CPEditTab.EditAndCheckout.Checkout-SelectedItem")))
                Checkin.click()
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on CHECK-IN Button \n")
                CheckinContinue = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, "statechangedialog_okbutton")))
                CheckinContinue.click()
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on Confirmation Button after CHECK-IN \n")
                ContentType = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.XPATH, "//span[contains(@class,'ms-Dropdown-title ms-Dropdown-titleIsPlaceHolder') and .//text()='Select an option']")))
                ContentType.click()
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on Content Type Drop Down \n")
                ContentTypeSelection = WebDriverWait(driver, 15).until(EC.visibility_of_element_located((By.XPATH, "//span[contains(@class,'ms-Dropdown-optionText dropdownOptionText') and .//text()='CEMLIs']")))
                ContentTypeSelection.click()
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Selection of Content Type Value from Drop Down \n")
                Track = WebDriverWait(driver, 15).until(EC.visibility_of_element_located((By.XPATH, "//span[contains(@class,'ms-Dropdown-title ms-Dropdown-titleIsPlaceHolder') and .//text()='Select options']")))
                Track.click()
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on Track Drop Down \n")
                TrackSelection = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.XPATH, "//span[contains(@class,'ms-Dropdown-optionText dropdownOptionText') and .//text()='Shared']")))
                TrackSelection.click()
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Selection of Track Value from Drop Down \n")
                Module = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.XPATH, "//span[contains(@class,'ms-Dropdown-title ms-Dropdown-titleIsPlaceHolder') and .//text()='Select options']")))
                Module.click()
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on Module Drop Down \n")
                ModuleSelection = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.XPATH, "//span[contains(@class,'ms-Dropdown-optionText dropdownOptionText') and .//text()='Sourcing']")))
                ModuleSelection.click()
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Selection of Module Value from Drop Down \n")
                JustClick = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.XPATH, "//label[contains(@class,'ms-Label ReactFieldEditor-fieldTitle') and .//text()='Description']")))
                JustClick.click()
                Description = driver.find_elements_by_xpath("//input[@placeholder='Enter value here']")[1].send_keys(CEMLI_NAME)
                time.sleep(2)
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on Enter Description and entering CEMLI Name as desription \n")
                Platform = driver.find_elements_by_xpath("//span[contains(@class,'ms-Dropdown-title ms-Dropdown-titleIsPlaceHolder') and .//text()='Select options']")[1].click()
                time.sleep(2)
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on Platform Drop Down \n")
                PlatformSelection = driver.find_elements_by_xpath("//span[contains(@class,'ms-Dropdown-optionText dropdownOptionText') and .//text()='SOA']")[0].click()
                time.sleep(3)
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Selection of Platform Value from Drop Down \n")
                DropdownClose = driver.find_elements_by_xpath("//span[contains(@class,'ms-Dropdown-caretDown') and .//text()='']")[5].click()
                time.sleep(2)
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on Platform Drop Down closure \n")
                SaveCEMLI = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.XPATH, "//span[contains(@class,'ms-Button-label') and .//text()='Save']")))
                SaveCEMLI.click()
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on Save Cemli Details \n")
                Edit = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.XPATH, "//span[contains(@class,'ms-promotedActionButton-text') and .//text()='Edit']")))
                Edit.click()
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on Edit Button for Final Check-Out \n")
                Checkout = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, "Ribbon.EditingTools.CPEditTab.EditAndCheckout.Checkout-SelectedItem")))
                Checkout.click()
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on Cehck-Out \n")
                Finalcheckout = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, "statechangedialog_okbutton")))
                Finalcheckout.click()
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Click on Final Check-Out Confirmation \n")
            
                print ("CEMLI Sheet has been created succesfully please find the below CEMLI Sheet Link \n ")
                print("https://geappliances.sharepoint.com/sites/erpdevops/SitePages/"+CEMLI_NAME+".aspx")
                fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "https://geappliances.sharepoint.com/sites/erpdevops/SitePages/"+CEMLI_NAME+".aspx \n")
        except NoSuchElementException:
            print ("Error Message :- Element Not Found and Execution got Failed \n Reason :- Element we are trying to access is not found or Slow Network Connection Time Out")
            fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Error Message :- Element Not Found and Execution got Failed \n Reason :- Element we are trying to access is not found or Slow Network Connection Time Out \n")
        except StaleElementReferenceException:
            print ("Error Message :- Stale Element reference \n Reason :- Stale Element means an old element or no longer available element")
            fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Error Message :- Stale Element reference \n Reason :- Stale Element means an old element or no longer available element \n")
        except Exception as e:
            print(e)
            print ("Error Message :- Some Thing Went Wrong or Flow Terminated abruptly  \n")
            fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "Error Message :- Some Thing Went Wrong or Flow Terminated abruptly  \n")
        finally:
            print("***************** CEMLI Creation Ended for " + CEMLI_NAME + "***************** ")
            fp.write(filename.strftime("%d-%B-%Y %H:%M:%S")+ " "+ "***************** CEMLI Creation Completed *****************")
        fp.close()
    
